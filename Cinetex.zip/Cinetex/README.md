# cinetex
Online Movie Theatre ticket Booking system
