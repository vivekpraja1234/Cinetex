export type Aggregate<Root> = Root
