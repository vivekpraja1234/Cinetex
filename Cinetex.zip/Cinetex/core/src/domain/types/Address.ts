export type Address = {
    street: string;
    city: string;
    state: string;
    zip: string;
}
