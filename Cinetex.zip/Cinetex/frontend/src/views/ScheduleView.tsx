import {UseCaseCollection} from "cinetex-core/dist/application/UseCaseCollection";
import React from "react";
import "../css/ScheduleView.css"

export default function ScheduleView({interactors}: { interactors: UseCaseCollection }) {
    return (
        <div id="ScheduleView">
            <h1>Schedule</h1>
        </div>
    )
}
